public class Petelka {
    static int a, b;
        
    public static void setA(int i){ a = i;}
    public static void setB(int i){ b = i;}
    public static int dodajAB(){ return (a + b);}
}