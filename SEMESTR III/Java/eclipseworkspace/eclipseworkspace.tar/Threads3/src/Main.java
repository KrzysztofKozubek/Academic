
public class Main {
	public static void main(String[] args) throws InterruptedException{
        Object lock = new Object();
        for(int i=0; i<5; i++){

            Thread t = new Thread(new Watek3(lock));
            t.start();
        }
    }
}
