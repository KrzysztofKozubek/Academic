///*
// * author : Wojciech Nowak
// * date   : 18.01.2017
// * version: 3.19
// */
//
//import org.omg.CosNaming.*;
//import org.omg.CORBA.*;
//import org.omg.PortableServer.*;
//
//import java.rmi.RemoteException;
//import java.util.ArrayList;
//import java.util.Map;
//import java.util.concurrent.Callable;
//import java.util.concurrent.ConcurrentHashMap;
//import java.util.concurrent.ExecutorService;
//import java.util.concurrent.Executors;
//import java.util.concurrent.Semaphore;
//import java.util.concurrent.atomic.AtomicInteger;
//
//public class ServiceImpl extends GeneratorPOA {
//
//	private Map<Integer,RMIGenerator> users = new ConcurrentHashMap<Integer,RMIGenerator>();						// users<userID, RMIGenerator>
//			Map<RMIGenerator,Semaphore> rmiServices = new ConcurrentHashMap<RMIGenerator,Semaphore>();				// rmiServices<RMIGenerator,Semaphore>
//			Map<Integer,Order> orders = new ConcurrentHashMap<Integer,Order>();										// orders<Integer,Order>
//			Map<Integer,Float> ready = new ConcurrentHashMap<Integer,Float>();
//			Map<RMIGenerator,ExecutorService> executors = new ConcurrentHashMap<RMIGenerator,ExecutorService>();	// executors<RMIGenerator,ExecutorService>
//			Semaphore regSem = new Semaphore(1,true);																// registering safely
//
//	private static AtomicInteger usID = new AtomicInteger(0);
//	private static AtomicInteger orID = new AtomicInteger(0);
//	Integer sum = 0;
//
//	@Override
//	public void register( String rmiServiceURL, IntHolder userID ) {
//		try {
//			regSem.acquireUninterruptibly();
//				RMIGenerator rmiService = Helper.getGenerator(rmiServiceURL);
//				if ( !users.containsKey(userID) ) {
//					userID.value = usID.incrementAndGet();
//					users.putIfAbsent(userID.value,rmiService);
//					rmiServices.putIfAbsent(rmiService,new Semaphore(rmiService.getThreads(),true));
//					executors.putIfAbsent(rmiService , Executors.newFixedThreadPool(rmiService.getThreads()));
//				}
//				else {
//					return;
//				}
//		}
//		catch (RemoteException e) {
//			System.out.println("register: RemoteException occured " + e.getMessage());
//		} finally {
//			regSem.release();
//		}
//	}
//
//	@Override
//	public void order( int userID, int averageOver, IntHolder orderID ) {
//		int orderIDvalue = orID.incrementAndGet();
//
//        ExecutorService schedulerExecutor  = Executors.newSingleThreadExecutor();
//        Scheduler scheduler = new Scheduler( userID, averageOver, orderIDvalue );
//        schedulerExecutor.submit(scheduler);
//
//	    orderID.value = orderIDvalue;
//	    return;
//	}
//
//	@Override
//	public boolean isReady( int orderID ) {
//		if( !orders.containsKey(orderID) ) {
//            return false;
//		}
//
//        return orders.get(orderID).isReady();
//	}
//
//	@Override
//	public float getAverage( int orderID ) {
//		int sum = 0;
//		ArrayList<Integer> temp = orders.get(orderID).values;
//		for ( int i : temp ) {
//			sum += i;
//		}
//		return (float)((float)sum / (float)orders.get(orderID).averageOver);
//	}
//
//	private class Scheduler implements Callable<Boolean> {
//		private int userID;
//				int averageOver;
//				int orderID;
//				RMIGenerator rmiGen;
//
//		public Scheduler( int uID, int aOver, int oID ) {
//			this.userID 	 = uID;
//			this.averageOver = aOver;
//			this.orderID 	 = oID;
//			this.rmiGen		 = users.get(userID);
//		}
//
//		@Override
//		public Boolean call() throws Exception {
//			orders.put(orderID, new Order(averageOver));
//			ExecutorService executor = executors.get(rmiGen);							// get executor for RMIGenerator instance
//			for (int i = 0 ; i < averageOver; i++) {									// generate aveareOver numbers
//	            callableGetValue c = new callableGetValue(rmiGen, orderID);
//	            executor.submit(c);
//	        }
//			return true;
//		}
//	}
//
//	private class callableGetValue implements Callable<Boolean>{
//		private RMIGenerator rmiGen;
//				int orderID;
//
//		callableGetValue (RMIGenerator r, int or) {
//			this.rmiGen   = r;
//			this.orderID  = or;
//		}
//
//		@Override
//		public Boolean call() throws Exception {
//			int val = rmiGen.getValue();
//			synchronized ( orders ) {
//				Order o = orders.get(orderID);
//				o.values.add( val );
//			}
//			return true;
//		}
//	}
//
//    private class Order{
//        private Integer averageOver;
//        public ArrayList<Integer> values;
//
//        public Order( int a ){
//            this.averageOver = a;
//            this.values = new ArrayList<>();
//        }
//        public boolean isReady(){
//            if( values.isEmpty() )
//                return false;
//            return values.size() == averageOver;
//        }
//    }
//
//}
//
//class Start {
//	public static void main(String[] argv) {
//	      try {
//	         ORB orb = ORB.init(argv, null);
//	         POA rootpoa = (POA)orb.resolve_initial_references("RootPOA");
//	         rootpoa.the_POAManager().activate();
//
//	         ServiceImpl service = new ServiceImpl();
//	         org.omg.CORBA.Object ref = rootpoa.servant_to_reference(service);
//
//	         System.out.println( orb.object_to_string( ref ) );
//
//	         org.omg.CORBA.Object namingContextObj = orb.resolve_initial_references("NameService");
//	         NamingContext namingContext = NamingContextHelper.narrow(namingContextObj);
//
//	         NameComponent[] path = {
//	            new NameComponent("Generator", "Object")
//	         };
//
//	         namingContext.rebind(path, ref);
//	         orb.run();
//	      } catch (Exception e) {
//	    	  e.printStackTrace();
//	      }
//	   }
//}