
public interface PMO_RunnableAndTestable extends Runnable, PMO_Testable {

}
